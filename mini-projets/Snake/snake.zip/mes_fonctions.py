def ou_va_tete(snake, deplacement, width, height):
    '''
    renvoie la future position de la tête du snake pour observer des collisions éventuelles
    '''
    pass


def manger_champignon(snake, deplacement, champignons, width, height):
    '''
    renvoie l'index du champignon qui va être mangé après deplacement
    si aucun champignon mangé, renvoie -1
    '''
    ou = ou_va_tete(snake, deplacement, width, height)
    pass
    return -1





def manger_snake(snake, deplacement, width, height):
    '''
    renvoie vrai si le snake se mange lui-même
    '''
    ou = ou_va_tete(snake, deplacement, width, height)
    pass
    return False


def avancer(snake, deplacement, width, height):
    '''
    avance d'une case le snake
    '''
    # corps
    pass
    # tete
    pass